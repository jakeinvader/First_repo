package com.yenku.chat.controller;

public enum MessageType {

    CHAT,

    JOIN,

    LEAVE
}
